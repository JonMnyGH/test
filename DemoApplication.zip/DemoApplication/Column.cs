using System;
using System.Collections.Generic;
using System.Text;

namespace DemoApplication
{
    public class Column
    {
        private string name;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        private Microsoft.SqlServer.Dts.Runtime.Wrapper.DataType dataType;

        public Microsoft.SqlServer.Dts.Runtime.Wrapper.DataType DataType
        {
            get { return dataType; }
            set { dataType = value; }
        }
        private int length;

        public int Length
        {
            get { return length; }
            set { length = value; }
        }

        private int precision;

        public int Precision
        {
            get { return precision; }
            set { precision = value; }
        }

        private int scale;

        public int Scale
        {
            get { return scale; }
            set { scale = value; }
        }

        private int codePage = 0;

        public int CodePage
        {
            get { return codePage; }
            set { codePage = value; }
        }
	
    }
}
